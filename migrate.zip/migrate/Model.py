# coding: utf-8
from sqlalchemy import BigInteger, Column, DateTime, Index, Integer, LargeBinary, String, Text
from sqlalchemy.schema import FetchedValue
from flask_sqlalchemy import SQLAlchemy


db = SQLAlchemy()



class Account(db.Model):
    __tablename__ = 'account'

    fpid = db.Column(db.BigInteger, primary_key=True, info='fpid the unique id from passport')
    last_login_time = db.Column(db.BigInteger, server_default=db.FetchedValue(), info='last login time')
    online_flag = db.Column(db.Integer, server_default=db.FetchedValue(), info='account is online or not')
    create_time = db.Column(db.BigInteger, nullable=False, info='create time')
    session_key = db.Column(db.String(256), server_default=db.FetchedValue(), info='passport session key')
    session_key_uptime = db.Column(db.BigInteger, server_default=db.FetchedValue(), info='session key update time')



class AchievementDatum(db.Model):
    __tablename__ = 'achievement_data'

    roleid = db.Column(db.BigInteger, primary_key=True, nullable=False, info='role id')
    cond_type = db.Column(db.Integer, primary_key=True, nullable=False, info='condition type id')
    param_must = db.Column(db.BigInteger, primary_key=True, nullable=False, server_default=db.FetchedValue(), info='int64 param must')
    ach_json_data = db.Column(db.Text, info='achievement pb serial to json data')
    ctime = db.Column(db.BigInteger, nullable=False, info='create time')
    update_time = db.Column(db.BigInteger, nullable=False, info='update time')



class ArenaCacheDatum(db.Model):
    __tablename__ = 'arena_cache_data'

    roleid = db.Column(db.BigInteger, primary_key=True, nullable=False, info='role id')
    slot_index = db.Column(db.Integer, primary_key=True, nullable=False)
    target_roleid = db.Column(db.BigInteger, nullable=False, info='target role id')
    cache_data = db.Column(db.Text, info='attacker json data')
    challenged = db.Column(db.Integer, nullable=False, info='0 false, 1 true')
    result = db.Column(db.Integer, nullable=False, info='battle result 0 loss,1 win')
    update_time = db.Column(db.BigInteger, nullable=False, info='update_time')



class ArenaRecordDatum(db.Model):
    __tablename__ = 'arena_record_data'

    id = db.Column(db.BigInteger, primary_key=True, nullable=False, info='id')
    roleid = db.Column(db.BigInteger, primary_key=True, nullable=False, info='role id')
    season_id = db.Column(db.Integer, nullable=False, info='season id')
    attacker_flag = db.Column(db.Integer, nullable=False, info='0 false, 1 true')
    challenged = db.Column(db.Integer, nullable=False, info='0 false, 1 true')
    attacker_info = db.Column(db.Text, info='attacker json data')
    defender_info = db.Column(db.Text, info='defender json data')
    result = db.Column(db.Integer, nullable=False, info='battle result 0 loss,1 win')
    record_time = db.Column(db.BigInteger, nullable=False, info='record time')
    update_time = db.Column(db.BigInteger, nullable=False, info='update time')
    src_id = db.Column(db.BigInteger, nullable=False, info='from id')
    fight_report = db.Column(db.Text, info='fight report json data')
    use_ticket = db.Column(db.Integer, server_default=db.FetchedValue(), info='whether use ticket')



class BuildingDatum(db.Model):
    __tablename__ = 'building_data'

    roleid = db.Column(db.BigInteger, primary_key=True, nullable=False, info='role id')
    building_id = db.Column(db.Integer, nullable=False, info='建筑id')
    building_pos = db.Column(db.Integer, primary_key=True, nullable=False, info='建筑建造的位置，类似背包的index是唯一的')
    building_state = db.Column(db.Integer, nullable=False, info='build state define in enum')
    building_idx = db.Column(db.Integer, nullable=False, info='区分相同建筑物的建造次序，不随位置的移动改变')
    bp_start_time = db.Column(db.BigInteger, server_default=db.FetchedValue(), info='建造的开始时间，单位UTC毫秒')
    bp_end_time = db.Column(db.BigInteger, server_default=db.FetchedValue(), info='建造的结束时间，单位UTC毫秒')
    cp_start_time = db.Column(db.BigInteger, server_default=db.FetchedValue(), info='资源类建筑的采集开始时间，单位UTC毫秒')
    cp_end_time = db.Column(db.BigInteger, server_default=db.FetchedValue(), info='资源类建筑的采集结束时间，单位UTC毫秒')
    pp_start_time = db.Column(db.BigInteger, server_default=db.FetchedValue(), info='训练营类建筑，研究或训练的开始时间，单位UTC毫秒')
    pp_end_time = db.Column(db.BigInteger, server_default=db.FetchedValue(), info='训练营类建筑，研究或训练的结束时间，单位UTC毫秒')
    camp_product = db.Column(db.Text, info='训练营类建筑的参数，json格式')



class ChatInfo(db.Model):
    __tablename__ = 'chat_info'

    roleid = db.Column(db.BigInteger, primary_key=True, info='role id')
    world_channel_id = db.Column(db.BigInteger, nullable=False, info='记录玩家所在的世界频道id')
    world_chat_time = db.Column(db.BigInteger, nullable=False, info='聊天时间')
    chat_content_crc = db.Column(db.BigInteger, server_default=db.FetchedValue(), info='聊天内容crc')
    chat_content_times = db.Column(db.BigInteger, server_default=db.FetchedValue(), info='内容重复次数')
    forbidden_time = db.Column(db.BigInteger, server_default=db.FetchedValue(), info='被禁言解禁时间')



class ClientDatum(db.Model):
    __tablename__ = 'client_data'

    roleid = db.Column(db.BigInteger, primary_key=True, info='role id')
    reddot_data = db.Column(db.Text, info='客户端的红点数据')



class DailyEventDatum(db.Model):
    __tablename__ = 'daily_event_data'

    roleid = db.Column(db.BigInteger, primary_key=True, nullable=False, info='role id')
    id = db.Column(db.Integer, primary_key=True, nullable=False, info='id, 对于DailyEventType')
    stage_id = db.Column(db.Integer, nullable=False, info='当前副本组id')
    dungeon_id = db.Column(db.Integer, nullable=False, index=True, info='下一个副本id, 0表示已完成所有副本')
    last_refresh_time = db.Column(db.BigInteger, info='次数下一次刷新时间，单位UTC毫秒, 参数同dailyreset')
    count = db.Column(db.Integer, nullable=False, info='累计刷新次数, 参数同dailyreset')
    begin_time = db.Column(db.BigInteger, info='事件开始时间，单位UTC毫秒, 参数同dailyreset')
    end_time = db.Column(db.BigInteger, info='事件结束时间，单位UTC毫秒, 参数同dailyreset')
    is_new = db.Column(db.Integer, server_default=db.FetchedValue(), info='是否为新的event（客户端是否需要显示弹板界面）')



class DailyEventPlot(db.Model):
    __tablename__ = 'daily_event_plot'

    roleid = db.Column(db.BigInteger, primary_key=True, nullable=False, info='role id')
    id = db.Column(db.Integer, primary_key=True, nullable=False, info='id, 对于DailyEventType')
    plot_id = db.Column(db.Integer, primary_key=True, nullable=False, server_default=db.FetchedValue(), info='剧情id')
    act_begin_time = db.Column(db.BigInteger, info='EDR_Type对于的活动开始时间，单位UTC毫秒')



class DailyResetDatum(db.Model):
    __tablename__ = 'daily_reset_data'

    roleid = db.Column(db.BigInteger, primary_key=True, nullable=False, info='role id')
    id = db.Column(db.Integer, primary_key=True, nullable=False, info='id,对于EDR_Type')
    value = db.Column(db.Integer, nullable=False, info='当前值')
    last_refresh_time = db.Column(db.BigInteger, info='最近的刷新时间，单位UTC毫秒')
    begin_time = db.Column(db.BigInteger, info='开始时间，单位UTC毫秒')
    end_time = db.Column(db.BigInteger, info='结束时间，单位UTC毫秒')



class DragonDatum(db.Model):
    __tablename__ = 'dragon_data'

    roleid = db.Column(db.BigInteger, primary_key=True, nullable=False, info='role id')
    dragon_id = db.Column(db.Integer, primary_key=True, nullable=False, info='dragon base id')
    dragon_level = db.Column(db.Integer, server_default=db.FetchedValue(), info='dragon level')
    gain_chips = db.Column(db.Integer, server_default=db.FetchedValue(), info='gain_chips')
    show_type = db.Column(db.Integer, server_default=db.FetchedValue(), info='show type:0 no,1 yes')
    battle_type = db.Column(db.Integer, server_default=db.FetchedValue(), info='battle type: 0 no,1 yes')
    level_uptime = db.Column(db.BigInteger, server_default=db.FetchedValue(), info='stage update time')
    create_time = db.Column(db.BigInteger, server_default=db.FetchedValue(), info='create time')
    team_info = db.Column(db.Text, info='team belongs to')



class DragonTaskDatum(db.Model):
    __tablename__ = 'dragon_task_data'
    __table_args__ = (
        db.Index('roleid', 'roleid', 'task_id'),
    )

    roleid = db.Column(db.BigInteger, primary_key=True, nullable=False, info='role id')
    slot_seq = db.Column(db.Integer, primary_key=True, nullable=False, server_default=db.FetchedValue(), info='the sequence of slot')
    task_id = db.Column(db.Integer, nullable=False, info='the task id')
    dragon_id = db.Column(db.Integer, nullable=False, info='dragon base id')
    task_status = db.Column(db.Integer, server_default=db.FetchedValue(), info='the status')
    status_uptime = db.Column(db.BigInteger, server_default=db.FetchedValue(), info='status update time')
    create_time = db.Column(db.BigInteger, server_default=db.FetchedValue(), info='create time')



class DungeonDatum(db.Model):
    __tablename__ = 'dungeon_data'

    roleid = db.Column(db.BigInteger, primary_key=True, nullable=False, info='role id')
    dungeon_id = db.Column(db.Integer, primary_key=True, nullable=False, info='副本id')
    chapter_id = db.Column(db.Integer, nullable=False, index=True, info='章节id')
    start_time = db.Column(db.BigInteger, server_default=db.FetchedValue(), info='副本的开始时间，单位UTC毫秒')
    end_time = db.Column(db.BigInteger, server_default=db.FetchedValue(), info='副本的结束时间，单位UTC毫秒')
    reward_status = db.Column(db.Integer, server_default=db.FetchedValue(), info='0: 不可领奖 1:可领奖 2:已领奖')
    chest_json_data = db.Column(db.Text, info='taken chest id list pb serial to json data')



class EquipDatum(db.Model):
    __tablename__ = 'equip_data'

    roleid = db.Column(db.BigInteger, primary_key=True, nullable=False, info='role id')
    item_id = db.Column(db.Integer, nullable=False, index=True, info='物品id')
    equip_gid = db.Column(db.Integer, primary_key=True, nullable=False, info='equipment global id')
    level = db.Column(db.Integer, server_default=db.FetchedValue(), info='等级')
    exp = db.Column(db.Integer, server_default=db.FetchedValue(), info='经验值')
    intensify_level = db.Column(db.Integer, server_default=db.FetchedValue(), info='强化等级')
    intensify_attr = db.Column(db.Text, info='强化属性')
    skill_level = db.Column(db.Integer, server_default=db.FetchedValue(), info='被动技能等级')
    hero_gid = db.Column(db.Integer, server_default=db.FetchedValue(), info='归属英雄')
    locked = db.Column(db.Integer, server_default=db.FetchedValue(), info='是否上锁')



class GameGlobal(db.Model):
    __tablename__ = 'game_global'

    roleid = db.Column(db.BigInteger, primary_key=True, info='role id')
    idgen = db.Column(db.Integer, server_default=db.FetchedValue(), info='玩家唯一id生成器,自增')
    building = db.Column(db.Text, info='Building系统的全局数据，比如解锁区域')
    dungeon = db.Column(db.Text, info='dungeon系统的全局数据，比如解锁章節')
    mail = db.Column(db.Text, info='mail系统的全局数据，比如全局邮件上次获取时间')
    dragon_lair = db.Column(db.Text, info='dragon系统全局数据，如刷新任务时间，当天刷新次数')
    achv_trigger = db.Column(db.Text, info='achv_trigger系统全局数据，key,value已触发过的类型,id')



class GameSysUnlockDatum(db.Model):
    __tablename__ = 'game_sys_unlock_data'

    roleid = db.Column(db.BigInteger, primary_key=True, nullable=False, info='role id')
    id = db.Column(db.Integer, primary_key=True, nullable=False, info='id,对于EGameSysType')
    value = db.Column(db.Integer, nullable=False, info='当前值')



class GlobalArena(db.Model):
    __tablename__ = 'global_arena'

    id = db.Column(db.Integer, primary_key=True, info='arena season id')
    created_time = db.Column(db.BigInteger, server_default=db.FetchedValue(), info='create time')
    updated_time = db.Column(db.BigInteger, server_default=db.FetchedValue(), info='status update time')



class GlobalArenaJob(db.Model):
    __tablename__ = 'global_arena_job'

    id = db.Column(db.Integer, primary_key=True)
    job_id = db.Column(db.String(128), nullable=False, unique=True, info='unique job id')
    job_args = db.Column(db.String(256), server_default=db.FetchedValue(), info='job args')
    job_time = db.Column(db.BigInteger, server_default=db.FetchedValue(), info='job time')
    created_time = db.Column(db.BigInteger, server_default=db.FetchedValue(), info='create time')
    create_node = db.Column(db.String(128), server_default=db.FetchedValue(), info='create node')
    handle_time = db.Column(db.BigInteger, server_default=db.FetchedValue(), info='handle time')
    handle_result = db.Column(db.Integer, server_default=db.FetchedValue(), info='handle result')
    handle_node = db.Column(db.String(128), server_default=db.FetchedValue(), info='handle node')
    job_prefix = db.Column(db.String(256), nullable=False, server_default=db.FetchedValue(), info='job_prefix')
    season_id = db.Column(db.Integer, nullable=False, server_default=db.FetchedValue(), info='arena season id')



class GlobalBlackList(db.Model):
    __tablename__ = 'global_black_list'

    roleid = db.Column(db.BigInteger, primary_key=True, server_default=db.FetchedValue(), info='角色id')
    action_time = db.Column(db.BigInteger, server_default=db.FetchedValue(), info='违规时间')
    action_type = db.Column(db.Integer, server_default=db.FetchedValue(), info='违规类型')
    times = db.Column(db.Integer, server_default=db.FetchedValue(), info='违规次数')



class GlobalBossBattle(db.Model):
    __tablename__ = 'global_boss_battle'

    id = db.Column(db.Integer, primary_key=True, info='serial id')
    rule_id = db.Column(db.Integer, server_default=db.FetchedValue(), info='rule_id')
    stage_id = db.Column(db.Integer, server_default=db.FetchedValue(), info='stage_id')
    created_time = db.Column(db.BigInteger, server_default=db.FetchedValue(), info='create time')
    start_time = db.Column(db.BigInteger, server_default=db.FetchedValue(), info='start_time')
    end_time = db.Column(db.BigInteger, server_default=db.FetchedValue(), info='end_time')
    destroy_time = db.Column(db.BigInteger, server_default=db.FetchedValue(), info='destroy_time')
    reward_time = db.Column(db.BigInteger, server_default=db.FetchedValue(), info='reward_time')
    send_reward_time = db.Column(db.BigInteger, server_default=db.FetchedValue(), info='send_reward_time')
    join_player_num = db.Column(db.Integer, server_default=db.FetchedValue(), info='join_player_num')
    update_time = db.Column(db.BigInteger, server_default=db.FetchedValue(), info='update_time')
    boss_data = db.Column(db.Text, info='boss_data')
    fight_record = db.Column(db.Text, info='fight_record')
    robot_role_ids = db.Column(db.Text, info='robot_role_ids')



class GlobalChatWorldChannel(db.Model):
    __tablename__ = 'global_chat_world_channel'

    id = db.Column(db.BigInteger, primary_key=True, info='id value')
    online = db.Column(db.Integer, server_default=db.FetchedValue(), info='online num')



class GlobalGreyList(db.Model):
    __tablename__ = 'global_grey_list'

    roleid = db.Column(db.BigInteger, primary_key=True, server_default=db.FetchedValue(), info='角色id')
    action_time = db.Column(db.BigInteger, server_default=db.FetchedValue(), info='违规时间')
    action_type = db.Column(db.Integer, server_default=db.FetchedValue(), info='违规类型')
    times = db.Column(db.Integer, server_default=db.FetchedValue(), info='违规次数')



class GlobalIdGen92(db.Model):
    __tablename__ = 'global_id_gen_92'

    id = db.Column(db.BigInteger, nullable=False, unique=True)
    stub = db.Column(db.String(1), primary_key=True, server_default=db.FetchedValue())



class GlobalIdGen93(db.Model):
    __tablename__ = 'global_id_gen_93'

    id = db.Column(db.BigInteger, nullable=False, unique=True)
    stub = db.Column(db.String(1), primary_key=True, server_default=db.FetchedValue())



class GlobalIdGen94(db.Model):
    __tablename__ = 'global_id_gen_94'

    id = db.Column(db.BigInteger, nullable=False, unique=True)
    stub = db.Column(db.String(1), primary_key=True, server_default=db.FetchedValue())



class GlobalIdGen95(db.Model):
    __tablename__ = 'global_id_gen_95'

    id = db.Column(db.BigInteger, nullable=False, unique=True)
    stub = db.Column(db.String(1), primary_key=True, server_default=db.FetchedValue())



class GlobalIdGen96(db.Model):
    __tablename__ = 'global_id_gen_96'

    id = db.Column(db.BigInteger, nullable=False, unique=True)
    stub = db.Column(db.String(1), primary_key=True, server_default=db.FetchedValue())



class GlobalIdGen97(db.Model):
    __tablename__ = 'global_id_gen_97'

    id = db.Column(db.BigInteger, nullable=False, unique=True)
    stub = db.Column(db.String(1), primary_key=True, server_default=db.FetchedValue())



class GlobalIdGen98(db.Model):
    __tablename__ = 'global_id_gen_98'

    id = db.Column(db.BigInteger, nullable=False, unique=True)
    stub = db.Column(db.String(1), primary_key=True, server_default=db.FetchedValue())



class GlobalIdGen99(db.Model):
    __tablename__ = 'global_id_gen_99'

    id = db.Column(db.BigInteger, nullable=False, unique=True)
    stub = db.Column(db.String(1), primary_key=True, server_default=db.FetchedValue())



class GlobalJobWorker(db.Model):
    __tablename__ = 'global_job_worker'

    id = db.Column(db.Integer, primary_key=True)
    job_id = db.Column(db.String(128), nullable=False, info='redis job id')
    job_name = db.Column(db.String(128), nullable=False, unique=True, info='unique job name')
    job_time = db.Column(db.BigInteger, server_default=db.FetchedValue(), info='job time')
    job_args = db.Column(db.String(256), server_default=db.FetchedValue(), info='job args')
    job_owner_id = db.Column(db.BigInteger, server_default=db.FetchedValue(), info='job owner id')
    job_period = db.Column(db.Integer, server_default=db.FetchedValue(), info='job_period ms')
    job_max_times = db.Column(db.Integer, server_default=db.FetchedValue(), info='job_max_times')
    created_time = db.Column(db.BigInteger, server_default=db.FetchedValue(), info='create time')
    create_node = db.Column(db.String(128), server_default=db.FetchedValue(), info='create node')
    handle_time = db.Column(db.BigInteger, server_default=db.FetchedValue(), info='handle time')
    handle_result = db.Column(db.Integer, server_default=db.FetchedValue(), info='handle result times')
    handle_node = db.Column(db.String(128), server_default=db.FetchedValue(), info='handle node')



class GlobalMail(db.Model):
    __tablename__ = 'global_mail'

    id = db.Column(db.BigInteger, primary_key=True, info='自增主键')
    sender = db.Column(db.String(128), server_default=db.FetchedValue(), info='发件人')
    title = db.Column(db.String(1024), server_default=db.FetchedValue(), info='主题')
    content = db.Column(db.String(4096), server_default=db.FetchedValue(), info='正文')
    salute = db.Column(db.String(128), server_default=db.FetchedValue(), info='落款敬词')
    attachment = db.Column(db.String(4096), server_default=db.FetchedValue(), info='附件')
    created_time = db.Column(db.BigInteger, index=True, server_default=db.FetchedValue(), info='时间戳')
    expired_time = db.Column(db.BigInteger, server_default=db.FetchedValue(), info='过期时间戳')



class GlobalSealAccountDeviceid(db.Model):
    __tablename__ = 'global_seal_account_deviceid'

    id = db.Column(db.BigInteger, primary_key=True, info='device id int value')
    device_id = db.Column(db.String(128), server_default=db.FetchedValue(), info='device id')
    expired_time = db.Column(db.BigInteger, info='过期时间，单位UTC毫秒')



class GlobalSealAccountFpid(db.Model):
    __tablename__ = 'global_seal_account_fpid'

    id = db.Column(db.BigInteger, primary_key=True, info='fpid')
    expired_time = db.Column(db.BigInteger, info='过期时间，单位UTC毫秒')



class GlobalServerMaintenance(db.Model):
    __tablename__ = 'global_server_maintenance'

    id = db.Column(db.BigInteger, primary_key=True, info='自增主键')
    notify_time = db.Column(db.BigInteger, server_default=db.FetchedValue(), info='广播时间')
    notify_interval_minutes = db.Column(db.Integer, server_default=db.FetchedValue(), info='广播时间间隔(分)')
    maintenance_time = db.Column(db.BigInteger, server_default=db.FetchedValue(), info='维护时间')
    maintenance_interval_minutes = db.Column(db.Integer, server_default=db.FetchedValue(), info='维护时长(分)')
    created_time = db.Column(db.BigInteger, index=True, server_default=db.FetchedValue(), info='created time')
    expired_time = db.Column(db.BigInteger, server_default=db.FetchedValue(), info='expired time')



class GlobalUserReport(db.Model):
    __tablename__ = 'global_user_report'

    report_role_id = db.Column(db.BigInteger, primary_key=True, nullable=False, server_default=db.FetchedValue(), info='举报人角色id')
    target_role_id = db.Column(db.BigInteger, primary_key=True, nullable=False, server_default=db.FetchedValue(), info='被举报角色id')
    desc_crc = db.Column(db.BigInteger, primary_key=True, nullable=False, server_default=db.FetchedValue(), info='举报内容 crc')
    desc_str = db.Column(db.String(255), nullable=False, info='举报内容')
    report_time = db.Column(db.BigInteger, server_default=db.FetchedValue(), info='report time')



class GlobalUserReportStat(db.Model):
    __tablename__ = 'global_user_report_stat'

    role_id = db.Column(db.BigInteger, primary_key=True, nullable=False, info='被举报角色id')
    report_desc_crc = db.Column(db.BigInteger, primary_key=True, nullable=False, server_default=db.FetchedValue(), info='举报内容crc')
    report_times = db.Column(db.Integer, server_default=db.FetchedValue(), info='被举报次数')
    report_time = db.Column(db.BigInteger, server_default=db.FetchedValue(), info='report time')



class GlobalWhitelistFpid(db.Model):
    __tablename__ = 'global_whitelist_fpid'

    id = db.Column(db.BigInteger, primary_key=True, info='fpid')



class GlobalWhitelistIp(db.Model):
    __tablename__ = 'global_whitelist_ip'

    id = db.Column(db.BigInteger, primary_key=True, info='ip addr int value')
    ip_addr = db.Column(db.String(32), server_default=db.FetchedValue(), info='ip_addr')



class HeadIconDatum(db.Model):
    __tablename__ = 'head_icon_data'

    roleid = db.Column(db.BigInteger, primary_key=True, nullable=False, info='role id')
    head_icon_id = db.Column(db.Integer, primary_key=True, nullable=False, info='head icon id')
    create_time = db.Column(db.BigInteger, nullable=False, info='create time')
    expired_time = db.Column(db.BigInteger, nullable=False, info='expired time')
    expired = db.Column(db.Integer, nullable=False, server_default=db.FetchedValue(), info='expired flag 0 no 1 yes')



class HeroDatum(db.Model):
    __tablename__ = 'hero_data'

    roleid = db.Column(db.BigInteger, primary_key=True, nullable=False, info='role id')
    hero_id = db.Column(db.Integer, nullable=False, info='hero conf id')
    hero_gid = db.Column(db.Integer, primary_key=True, nullable=False, info='英雄的全局自增id')
    level = db.Column(db.Integer, server_default=db.FetchedValue(), info='等级')
    exp = db.Column(db.Integer, server_default=db.FetchedValue(), info='经验值')
    ascension_level = db.Column(db.Integer, server_default=db.FetchedValue(), info='进阶等级')
    red_star_level = db.Column(db.Integer, server_default=db.FetchedValue(), info='红星等级')
    skill_level = db.Column(db.Integer, server_default=db.FetchedValue(), info='技能等级')
    team_info = db.Column(db.Text, info='归属队伍')
    locked = db.Column(db.Integer, server_default=db.FetchedValue(), info='是否上锁')
    equip_gid = db.Column(db.Integer, server_default=db.FetchedValue(), info='装备的全局自增id')



class HeroTeam(db.Model):
    __tablename__ = 'hero_team'

    roleid = db.Column(db.BigInteger, primary_key=True, nullable=False, info='role id')
    team_id = db.Column(db.Integer, primary_key=True, nullable=False, info='team id')
    team_name = db.Column(db.String(128), info='team name')
    team_data = db.Column(db.Text, info='Hero系统的队伍信息')



class InteractiveDatum(db.Model):
    __tablename__ = 'interactive_data'

    roleid = db.Column(db.BigInteger, primary_key=True, nullable=False, info='role id')
    id = db.Column(db.BigInteger, primary_key=True, nullable=False, info='id')
    data_type = db.Column(db.Integer, nullable=False, info='interactive data type')
    data_info = db.Column(db.Text, info='interactive json data')
    create_time = db.Column(db.BigInteger, nullable=False, info='create time')
    update_time = db.Column(db.BigInteger, nullable=False, info='handle update time')
    deleted = db.Column(db.Integer, nullable=False, info='0 no,1 yes')



class ItemDatum(db.Model):
    __tablename__ = 'item_data'

    roleid = db.Column(db.BigInteger, primary_key=True, nullable=False, info='role id')
    id = db.Column(db.Integer, primary_key=True, nullable=False, info='id')
    item_id = db.Column(db.Integer, nullable=False, index=True, info='物品id')
    count = db.Column(db.Integer, nullable=False, info='物品数量')



class LotteryDatum(db.Model):
    __tablename__ = 'lottery_data'

    roleid = db.Column(db.BigInteger, primary_key=True, nullable=False, info='role id')
    lottery_id = db.Column(db.Integer, primary_key=True, nullable=False, info='抽奖id')
    lottery_times = db.Column(db.Integer, nullable=False, info='抽奖次数')
    must_times = db.Column(db.Integer, nullable=False, info='保底次数')
    free_times = db.Column(db.Integer, nullable=False, info='免费抽取的次数')
    refresh_time = db.Column(db.BigInteger, server_default=db.FetchedValue(), info='商店刷新时间ms，单位UTC毫秒')
    expired_time = db.Column(db.BigInteger, server_default=db.FetchedValue(), info='商店过期时间ms，单位UTC毫秒')



class Metadatum(db.Model):
    __tablename__ = 'metadata'

    id = db.Column(db.BigInteger, primary_key=True)
    name = db.Column(db.String(128), nullable=False, unique=True, server_default=db.FetchedValue())
    hash = db.Column(db.String(128), nullable=False, server_default=db.FetchedValue())
    content = db.Column(db.Text, nullable=False)
    mtime = db.Column(db.DateTime, server_default=db.FetchedValue())



class PlayerArena(db.Model):
    __tablename__ = 'player_arena'

    roleid = db.Column(db.BigInteger, primary_key=True, info='role id')
    score = db.Column(db.BigInteger, nullable=False, info='arena score')
    challenge_times = db.Column(db.Integer, nullable=False, info='challenge times of current day')
    defence_team = db.Column(db.Text, info='defence team data')
    defence_formation_id = db.Column(db.Integer, info='defence formation id')
    defence_team_uptime = db.Column(db.BigInteger, server_default=db.FetchedValue(), info='defence_team update time')
    inited_rank = db.Column(db.Integer, server_default=db.FetchedValue(), info='false not, true inited rank')
    defence_max_power = db.Column(db.Integer, nullable=False, server_default=db.FetchedValue(), info='history max power of defence team')
    attack_max_power = db.Column(db.Integer, nullable=False, server_default=db.FetchedValue(), info='history max power of attack team')



class PlayerBos(db.Model):
    __tablename__ = 'player_boss'

    roleid = db.Column(db.BigInteger, primary_key=True, info='role id')
    battle_id = db.Column(db.BigInteger, server_default=db.FetchedValue(), info='battle id')
    rule_id = db.Column(db.Integer, server_default=db.FetchedValue(), info='rule id')
    score = db.Column(db.BigInteger, server_default=db.FetchedValue(), info='acc score')
    cur_damage = db.Column(db.BigInteger, server_default=db.FetchedValue(), info='cur damage')
    battle_end_time = db.Column(db.BigInteger, server_default=db.FetchedValue(), info='battle end time')
    take_reward_time = db.Column(db.BigInteger, server_default=db.FetchedValue(), info='take reward time')



class PlayerMail(db.Model):
    __tablename__ = 'player_mail'

    id = db.Column(db.BigInteger, primary_key=True, info='邮件id')
    roleid = db.Column(db.BigInteger, nullable=False, index=True, info='role id')
    sender = db.Column(db.String(128), server_default=db.FetchedValue(), info='发件人')
    title = db.Column(db.String(1024), server_default=db.FetchedValue(), info='主题')
    content = db.Column(db.String(4096), server_default=db.FetchedValue(), info='正文')
    salute = db.Column(db.String(128), server_default=db.FetchedValue(), info='落款敬词')
    attachment = db.Column(db.String(4096), server_default=db.FetchedValue(), info='附件')
    read_flag = db.Column(db.Integer, server_default=db.FetchedValue(), info='是否已读')
    attach_received = db.Column(db.Integer, server_default=db.FetchedValue(), info='是否已领取附件，默认为未领取')
    created_time = db.Column(db.BigInteger, server_default=db.FetchedValue(), info='时间戳')
    expired_time = db.Column(db.BigInteger, server_default=db.FetchedValue(), info='过期时间戳')
    mail_type = db.Column(db.Integer, server_default=db.FetchedValue(), info='邮件类型')
    global_id = db.Column(db.BigInteger, server_default=db.FetchedValue(), info='全局邮件对应的id')
    mail_param = db.Column(db.String(4096), server_default=db.FetchedValue(), info='邮件参数')
    extra_conf_id = db.Column(db.Integer, server_default=db.FetchedValue(), info='邮件配表id（默认为0）')



class PlayerName(db.Model):
    __tablename__ = 'player_name'

    server_id = db.Column(db.Integer, primary_key=True, nullable=False, info='server_id')
    roleid = db.Column(db.BigInteger, primary_key=True, nullable=False, info='role id')
    name_crc = db.Column(db.BigInteger, nullable=False, index=True, info='name_crc')
    name = db.Column(db.String(128), server_default=db.FetchedValue(), info='名字')



class PlayerShowDatum(db.Model):
    __tablename__ = 'player_show_data'

    roleid = db.Column(db.BigInteger, primary_key=True, info='role id')
    show_hero = db.Column(db.Text, info='show hero data')
    show_dragon = db.Column(db.Text, info='show dragon data')
    guild_id = db.Column(db.BigInteger, nullable=False, server_default=db.FetchedValue(), info='guild id')
    guild_title_id = db.Column(db.Integer, nullable=False, server_default=db.FetchedValue(), info='guild title id')
    show_power = db.Column(db.Integer, nullable=False, server_default=db.FetchedValue())
    show_dungeon_id = db.Column(db.Integer, nullable=False, server_default=db.FetchedValue(), info='max pass dungeon id')
    create_time = db.Column(db.BigInteger, nullable=False, info='create time')
    update_time = db.Column(db.BigInteger, nullable=False, info='update time')
    show_hero_inited = db.Column(db.Integer, server_default=db.FetchedValue(), info='init show hero flag')



class PlogSetting(db.Model):
    __tablename__ = 'plog_setting'

    tag = db.Column(db.String(128), primary_key=True, info='tag')
    enable_mode_list = db.Column(db.String(255), nullable=False, info='mode list')
    log_level_site = db.Column(db.Integer, nullable=False, info='log level')
    log_output_site = db.Column(db.Integer, nullable=False, info='log out type')
    unity_log_open = db.Column(db.Integer, server_default=db.FetchedValue(), info='unity log status')



class QualitySetting(db.Model):
    __tablename__ = 'quality_setting'

    fpid = db.Column(db.BigInteger, primary_key=True, info='fpid')
    device_module = db.Column(db.String(128), server_default=db.FetchedValue(), info='设备名')
    cpu_name = db.Column(db.String(128), server_default=db.FetchedValue(), info='CPU名字')
    cpu_core_num = db.Column(db.Integer, server_default=db.FetchedValue(), info='CPU核心数')
    gpu_shader_level = db.Column(db.Integer, server_default=db.FetchedValue(), info='shader level')
    gpu_name = db.Column(db.String(128), server_default=db.FetchedValue(), info='GPU名字')
    memory_size = db.Column(db.Integer, server_default=db.FetchedValue(), info='内存')
    gpu_memory_size = db.Column(db.Integer, server_default=db.FetchedValue(), info='显存')
    config_id = db.Column(db.Integer, server_default=db.FetchedValue(), info='上次配置id')



class ResourceDatum(db.Model):
    __tablename__ = 'resource_data'

    roleid = db.Column(db.BigInteger, primary_key=True, nullable=False, info='role id')
    resource_id = db.Column(db.Integer, primary_key=True, nullable=False, server_default=db.FetchedValue(), info='资源id')
    resource_value = db.Column(db.BigInteger, nullable=False, server_default=db.FetchedValue(), info='数量')
    last_refresh_time = db.Column(db.BigInteger, info='最近的刷新时间，单位UTC毫秒')



class RobotDatum(db.Model):
    __tablename__ = 'robot_data'

    roleid = db.Column(db.BigInteger, primary_key=True, info='role id')
    table_id = db.Column(db.Integer, nullable=False, unique=True, info='robot table id')
    role_info = db.Column(db.Text, info='role info')
    hero_info = db.Column(db.Text, info='hero info')
    weapon_info = db.Column(db.Text, info='weapon info')
    dragon_info = db.Column(db.Text, info='dragon info')
    arena_info = db.Column(db.Text, info='arena info')
    show_info = db.Column(db.Text, info='show info')
    create_time = db.Column(db.BigInteger, nullable=False, info='create time')
    robot_type = db.Column(db.Integer, server_default=db.FetchedValue(), info='robot type 1 arena,2 boss')



class RoleInfo(db.Model):
    __tablename__ = 'role_info'

    roleid = db.Column(db.BigInteger, primary_key=True, info='role id')
    fpid = db.Column(db.BigInteger, nullable=False, index=True, info='fpid the unique id from passport')
    serverid = db.Column(db.Integer, nullable=False, info='serverid for create role')
    ctime = db.Column(db.BigInteger, nullable=False, info='create time')
    level = db.Column(db.Integer, nullable=False, server_default=db.FetchedValue(), info='role level')
    title_level = db.Column(db.Integer, nullable=False, server_default=db.FetchedValue(), info='role title level')
    diamond_buy = db.Column(db.BigInteger, server_default=db.FetchedValue(), info='diamond buy from appstore')
    diamond_gift = db.Column(db.BigInteger, server_default=db.FetchedValue(), info='diamond obtain from game')
    diamond_used = db.Column(db.BigInteger, server_default=db.FetchedValue(), info='diamond used')
    prologue_passed = db.Column(db.Integer, server_default=db.FetchedValue(), info='prologue pass or not')
    gender = db.Column(db.Integer, nullable=False, server_default=db.FetchedValue(), info='role gender')
    name = db.Column(db.String(128), server_default=db.FetchedValue(), info='player name')
    last_logout_time = db.Column(db.BigInteger, server_default=db.FetchedValue(), info='last logout millisecond')
    signature = db.Column(db.String(256), server_default=db.FetchedValue(), info='individual signature')
    icon_id = db.Column(db.Integer, nullable=False, server_default=db.FetchedValue(), info='head icon id')
    icon_frame_id = db.Column(db.Integer, nullable=False, server_default=db.FetchedValue(), info='head icon frame id')
    mod_name_cnt = db.Column(db.Integer, nullable=False, server_default=db.FetchedValue(), info='modify name count')
    check_interactive_time = db.Column(db.BigInteger, server_default=db.FetchedValue(), info='last check time')



class SevendayLogin(db.Model):
    __tablename__ = 'sevenday_login'

    roleid = db.Column(db.BigInteger, primary_key=True, nullable=False, info='role id')
    id = db.Column(db.Integer, primary_key=True, nullable=False, info='id')
    timestamp = db.Column(db.BigInteger, server_default=db.FetchedValue(), info='可领取时间，单位UTC毫秒')
    take_flag = db.Column(db.Integer, server_default=db.FetchedValue(), info='1:已领取奖励 0：未领取奖励')



class ShopDatum(db.Model):
    __tablename__ = 'shop_data'

    roleid = db.Column(db.BigInteger, primary_key=True, nullable=False, info='角色id')
    shop_id = db.Column(db.Integer, primary_key=True, nullable=False, info='商店id')
    begin_time = db.Column(db.BigInteger, server_default=db.FetchedValue(), info='开始时间，单位UTC毫秒')
    end_time = db.Column(db.BigInteger, server_default=db.FetchedValue(), info='结束时间，单位UTC毫秒')
    products_blob = db.Column(db.Text, info='商品信息')



class TaskDatum(db.Model):
    __tablename__ = 'task_data'

    roleid = db.Column(db.BigInteger, primary_key=True, nullable=False, info='role id')
    task_status = db.Column(db.Integer, primary_key=True, nullable=False, info='任务状态，比如已完成任务、已激活任务')
    task_sharding = db.Column(db.Integer, primary_key=True, nullable=False, info='对任务做一个分片处理')
    detail_data = db.Column(db.LargeBinary, info='任务的具体数据')



class TaskGroup(db.Model):
    __tablename__ = 'task_group'

    roleid = db.Column(db.BigInteger, primary_key=True, nullable=False, info='role id')
    group_status = db.Column(db.Integer, primary_key=True, nullable=False, info='任务组状态，比如已完成任务、已激活任务')
    group_sharding = db.Column(db.Integer, primary_key=True, nullable=False, info='对任务组做一个分片处理')
    detail_data = db.Column(db.LargeBinary, info='任务组的具体数据')



class User(db.Model):
    __tablename__ = 'user'

    fpid = db.Column(db.BigInteger, primary_key=True, nullable=False, info='fpid the unique id from passport')
    serverid = db.Column(db.Integer, primary_key=True, nullable=False, info='serverid for create role')
    roleid = db.Column(db.BigInteger, primary_key=True, nullable=False, info='role id')
    ctime = db.Column(db.BigInteger, nullable=False, info='create time')
    ipaddr = db.Column(db.String(64), server_default=db.FetchedValue(), info='ip address last login')
    deleted = db.Column(db.Integer, server_default=db.FetchedValue(), info='1 deleted ')
    deleted_time = db.Column(db.BigInteger, server_default=db.FetchedValue(), info='deleted time millisecond')
