#!/bin/bash

source "../../scripts/shlib.sh"

mysql_username=${1-root}
mysql_passwd=${2-123147}
mysql_host=${3-localhost}
mysql_port=${4-3306}

if [ "${DB_NAME}x" = "x" ]; then
    DB_NAME=${DEFAULT_DB_NAME}
fi

db_name_migrate=antia_server_migration
migrate_version=$(date "+%Y%m%d%H%M%S")

echo "DB_NAME:"${DB_NAME}

mysql -u"${mysql_username}" -p"${mysql_passwd}" -h"${mysql_host}" -P"${mysql_port}" -e "CREATE DATABASE IF NOT EXISTS ${DB_NAME} DEFAULT CHARSET utf8mb4 COLLATE utf8mb4_general_ci;"
mysql -u"${mysql_username}" -p"${mysql_passwd}" -h"${mysql_host}" -P"${mysql_port}" -e "CREATE DATABASE IF NOT EXISTS ${db_name_migrate} DEFAULT CHARSET utf8mb4 COLLATE utf8mb4_general_ci;"

# 生成myql数据库表
sh ../../scripts/create-db.sh ${mysql_username} ${mysql_passwd} ${mysql_host} ${mysql_port}

echo 'db name:'..${DB_NAME}
# 将mysql数据库表导出为flask-migrate的model文件
flask-sqlacodegen "mysql://${mysql_username}:${mysql_passwd}@${mysql_host}:${mysql_port}/${DB_NAME}" --outfile "Model.py" --flask

# 检查migrations目录是否存在
if [ ! -d "migrations" ]; then
    python3.7 manage.py db init
fi

# 执行python manage.py db migrate
python3.7 manage.py db migrate -m ${migrate_version}

# 执行python manage.py db upgrade --sql > migrate.sql
python3.7 manage.py db upgrade --sql > migrate.sql

# 执行检查是否有删除字段的操作
python3.7 checkmigrate.py

# 执行upgrade
python3.7 manage.py db upgrade

