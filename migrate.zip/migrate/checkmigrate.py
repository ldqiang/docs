import re

if __name__ == "__main__":
    # read migrate.sql
    full_path = "migrate.sql"
    with open(full_path, 'r') as fp:
        for sql in fp.readlines():
            matchObj = re.findall(r'DROP',sql,re.M|re.I)
            if matchObj:
                print("[ERROR] migrate will exec drop field,lost data!!! sql:{sql}".format(sql=sql))