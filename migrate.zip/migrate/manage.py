from flask_script import Command
from flask_migrate import Migrate, MigrateCommand
from flask_script import Manager
from flask import Flask
import Model
import pymysql

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql://root:123147@127.0.0.1:3306/antia_server_migration'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = True
app.config['SQLALCHEMY_ECHO'] = True


pymysql.install_as_MySQLdb()
Model.db.init_app(app)
migrate = Migrate(app, db=Model.db)

manager = Manager(app)
manager.add_command("db", MigrateCommand)

if __name__ == "__main__":
    manager.run()
