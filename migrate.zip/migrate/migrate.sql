CREATE TABLE alembic_version (
    version_num VARCHAR(32) NOT NULL, 
    CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num)
);

-- Running upgrade  -> b907b2d2adc1

CREATE TABLE account (
    fpid BIGINT NOT NULL AUTO_INCREMENT, 
    last_login_time BIGINT, 
    online_flag INTEGER, 
    create_time BIGINT NOT NULL, 
    session_key VARCHAR(256), 
    session_key_uptime BIGINT, 
    PRIMARY KEY (fpid)
);

CREATE TABLE achievement_data (
    roleid BIGINT NOT NULL, 
    cond_type INTEGER NOT NULL, 
    param_must BIGINT NOT NULL, 
    ach_json_data TEXT, 
    ctime BIGINT NOT NULL, 
    update_time BIGINT NOT NULL, 
    PRIMARY KEY (roleid, cond_type, param_must)
);

CREATE TABLE arena_cache_data (
    roleid BIGINT NOT NULL, 
    slot_index INTEGER NOT NULL, 
    target_roleid BIGINT NOT NULL, 
    cache_data TEXT, 
    challenged INTEGER NOT NULL, 
    result INTEGER NOT NULL, 
    update_time BIGINT NOT NULL, 
    PRIMARY KEY (roleid, slot_index)
);

CREATE TABLE arena_record_data (
    id BIGINT NOT NULL, 
    roleid BIGINT NOT NULL, 
    season_id INTEGER NOT NULL, 
    attacker_flag INTEGER NOT NULL, 
    challenged INTEGER NOT NULL, 
    attacker_info TEXT, 
    defender_info TEXT, 
    result INTEGER NOT NULL, 
    record_time BIGINT NOT NULL, 
    update_time BIGINT NOT NULL, 
    src_id BIGINT NOT NULL, 
    fight_report TEXT, 
    use_ticket INTEGER, 
    PRIMARY KEY (id, roleid)
);

CREATE TABLE building_data (
    roleid BIGINT NOT NULL, 
    building_id INTEGER NOT NULL, 
    building_pos INTEGER NOT NULL, 
    building_state INTEGER NOT NULL, 
    building_idx INTEGER NOT NULL, 
    bp_start_time BIGINT, 
    bp_end_time BIGINT, 
    cp_start_time BIGINT, 
    cp_end_time BIGINT, 
    pp_start_time BIGINT, 
    pp_end_time BIGINT, 
    camp_product TEXT, 
    PRIMARY KEY (roleid, building_pos)
);

CREATE TABLE chat_info (
    roleid BIGINT NOT NULL AUTO_INCREMENT, 
    world_channel_id BIGINT NOT NULL, 
    world_chat_time BIGINT NOT NULL, 
    chat_content_crc BIGINT, 
    chat_content_times BIGINT, 
    forbidden_time BIGINT, 
    PRIMARY KEY (roleid)
);

CREATE TABLE client_data (
    roleid BIGINT NOT NULL AUTO_INCREMENT, 
    reddot_data TEXT, 
    PRIMARY KEY (roleid)
);

CREATE TABLE daily_event_data (
    roleid BIGINT NOT NULL, 
    id INTEGER NOT NULL, 
    stage_id INTEGER NOT NULL, 
    dungeon_id INTEGER NOT NULL, 
    last_refresh_time BIGINT, 
    count INTEGER NOT NULL, 
    begin_time BIGINT, 
    end_time BIGINT, 
    is_new INTEGER, 
    PRIMARY KEY (roleid, id)
);

CREATE INDEX ix_daily_event_data_dungeon_id ON daily_event_data (dungeon_id);

CREATE TABLE daily_event_plot (
    roleid BIGINT NOT NULL, 
    id INTEGER NOT NULL, 
    plot_id INTEGER NOT NULL, 
    act_begin_time BIGINT, 
    PRIMARY KEY (roleid, id, plot_id)
);

CREATE TABLE daily_reset_data (
    roleid BIGINT NOT NULL, 
    id INTEGER NOT NULL, 
    value INTEGER NOT NULL, 
    last_refresh_time BIGINT, 
    begin_time BIGINT, 
    end_time BIGINT, 
    PRIMARY KEY (roleid, id)
);

CREATE TABLE dragon_data (
    roleid BIGINT NOT NULL, 
    dragon_id INTEGER NOT NULL, 
    dragon_level INTEGER, 
    gain_chips INTEGER, 
    show_type INTEGER, 
    battle_type INTEGER, 
    level_uptime BIGINT, 
    create_time BIGINT, 
    team_info TEXT, 
    PRIMARY KEY (roleid, dragon_id)
);

CREATE TABLE dragon_task_data (
    roleid BIGINT NOT NULL, 
    slot_seq INTEGER NOT NULL, 
    task_id INTEGER NOT NULL, 
    dragon_id INTEGER NOT NULL, 
    task_status INTEGER, 
    status_uptime BIGINT, 
    create_time BIGINT, 
    PRIMARY KEY (roleid, slot_seq)
);

CREATE INDEX roleid ON dragon_task_data (roleid, task_id);

CREATE TABLE dungeon_data (
    roleid BIGINT NOT NULL, 
    dungeon_id INTEGER NOT NULL, 
    chapter_id INTEGER NOT NULL, 
    start_time BIGINT, 
    end_time BIGINT, 
    reward_status INTEGER, 
    chest_json_data TEXT, 
    PRIMARY KEY (roleid, dungeon_id)
);

CREATE INDEX ix_dungeon_data_chapter_id ON dungeon_data (chapter_id);

CREATE TABLE equip_data (
    roleid BIGINT NOT NULL, 
    item_id INTEGER NOT NULL, 
    equip_gid INTEGER NOT NULL, 
    level INTEGER, 
    exp INTEGER, 
    intensify_level INTEGER, 
    intensify_attr TEXT, 
    skill_level INTEGER, 
    hero_gid INTEGER, 
    locked INTEGER, 
    PRIMARY KEY (roleid, equip_gid)
);

CREATE INDEX ix_equip_data_item_id ON equip_data (item_id);

CREATE TABLE game_global (
    roleid BIGINT NOT NULL AUTO_INCREMENT, 
    idgen INTEGER, 
    building TEXT, 
    dungeon TEXT, 
    mail TEXT, 
    dragon_lair TEXT, 
    achv_trigger TEXT, 
    PRIMARY KEY (roleid)
);

CREATE TABLE game_sys_unlock_data (
    roleid BIGINT NOT NULL, 
    id INTEGER NOT NULL, 
    value INTEGER NOT NULL, 
    PRIMARY KEY (roleid, id)
);

CREATE TABLE global_arena (
    id INTEGER NOT NULL AUTO_INCREMENT, 
    created_time BIGINT, 
    updated_time BIGINT, 
    PRIMARY KEY (id)
);

CREATE TABLE global_arena_job (
    id INTEGER NOT NULL AUTO_INCREMENT, 
    job_id VARCHAR(128) NOT NULL, 
    job_args VARCHAR(256), 
    job_time BIGINT, 
    created_time BIGINT, 
    create_node VARCHAR(128), 
    handle_time BIGINT, 
    handle_result INTEGER, 
    handle_node VARCHAR(128), 
    job_prefix VARCHAR(256) NOT NULL, 
    season_id INTEGER NOT NULL, 
    PRIMARY KEY (id), 
    UNIQUE (job_id)
);

CREATE TABLE global_black_list (
    roleid BIGINT NOT NULL, 
    action_time BIGINT, 
    action_type INTEGER, 
    times INTEGER, 
    PRIMARY KEY (roleid)
);

CREATE TABLE global_boss_battle (
    id INTEGER NOT NULL AUTO_INCREMENT, 
    rule_id INTEGER, 
    stage_id INTEGER, 
    created_time BIGINT, 
    start_time BIGINT, 
    end_time BIGINT, 
    destroy_time BIGINT, 
    reward_time BIGINT, 
    send_reward_time BIGINT, 
    join_player_num INTEGER, 
    update_time BIGINT, 
    boss_data TEXT, 
    fight_record TEXT, 
    robot_role_ids TEXT, 
    PRIMARY KEY (id)
);

CREATE TABLE global_chat_world_channel (
    id BIGINT NOT NULL AUTO_INCREMENT, 
    online INTEGER, 
    PRIMARY KEY (id)
);

CREATE TABLE global_grey_list (
    roleid BIGINT NOT NULL, 
    action_time BIGINT, 
    action_type INTEGER, 
    times INTEGER, 
    PRIMARY KEY (roleid)
);

CREATE TABLE global_id_gen_92 (
    id BIGINT NOT NULL, 
    stub VARCHAR(1) NOT NULL, 
    PRIMARY KEY (stub), 
    UNIQUE (id)
);

CREATE TABLE global_id_gen_93 (
    id BIGINT NOT NULL, 
    stub VARCHAR(1) NOT NULL, 
    PRIMARY KEY (stub), 
    UNIQUE (id)
);

CREATE TABLE global_id_gen_94 (
    id BIGINT NOT NULL, 
    stub VARCHAR(1) NOT NULL, 
    PRIMARY KEY (stub), 
    UNIQUE (id)
);

CREATE TABLE global_id_gen_95 (
    id BIGINT NOT NULL, 
    stub VARCHAR(1) NOT NULL, 
    PRIMARY KEY (stub), 
    UNIQUE (id)
);

CREATE TABLE global_id_gen_96 (
    id BIGINT NOT NULL, 
    stub VARCHAR(1) NOT NULL, 
    PRIMARY KEY (stub), 
    UNIQUE (id)
);

CREATE TABLE global_id_gen_97 (
    id BIGINT NOT NULL, 
    stub VARCHAR(1) NOT NULL, 
    PRIMARY KEY (stub), 
    UNIQUE (id)
);

CREATE TABLE global_id_gen_98 (
    id BIGINT NOT NULL, 
    stub VARCHAR(1) NOT NULL, 
    PRIMARY KEY (stub), 
    UNIQUE (id)
);

CREATE TABLE global_id_gen_99 (
    id BIGINT NOT NULL, 
    stub VARCHAR(1) NOT NULL, 
    PRIMARY KEY (stub), 
    UNIQUE (id)
);

CREATE TABLE global_job_worker (
    id INTEGER NOT NULL AUTO_INCREMENT, 
    job_id VARCHAR(128) NOT NULL, 
    job_name VARCHAR(128) NOT NULL, 
    job_time BIGINT, 
    job_args VARCHAR(256), 
    job_owner_id BIGINT, 
    job_period INTEGER, 
    job_max_times INTEGER, 
    created_time BIGINT, 
    create_node VARCHAR(128), 
    handle_time BIGINT, 
    handle_result INTEGER, 
    handle_node VARCHAR(128), 
    PRIMARY KEY (id), 
    UNIQUE (job_name)
);

CREATE TABLE global_mail (
    id BIGINT NOT NULL AUTO_INCREMENT, 
    sender VARCHAR(128), 
    title VARCHAR(1024), 
    content VARCHAR(4096), 
    salute VARCHAR(128), 
    attachment VARCHAR(4096), 
    created_time BIGINT, 
    expired_time BIGINT, 
    PRIMARY KEY (id)
);

CREATE INDEX ix_global_mail_created_time ON global_mail (created_time);

CREATE TABLE global_seal_account_deviceid (
    id BIGINT NOT NULL AUTO_INCREMENT, 
    device_id VARCHAR(128), 
    expired_time BIGINT, 
    PRIMARY KEY (id)
);

CREATE TABLE global_seal_account_fpid (
    id BIGINT NOT NULL AUTO_INCREMENT, 
    expired_time BIGINT, 
    PRIMARY KEY (id)
);

CREATE TABLE global_server_maintenance (
    id BIGINT NOT NULL AUTO_INCREMENT, 
    notify_time BIGINT, 
    notify_interval_minutes INTEGER, 
    maintenance_time BIGINT, 
    maintenance_interval_minutes INTEGER, 
    created_time BIGINT, 
    expired_time BIGINT, 
    PRIMARY KEY (id)
);

CREATE INDEX ix_global_server_maintenance_created_time ON global_server_maintenance (created_time);

CREATE TABLE global_user_report (
    report_role_id BIGINT NOT NULL, 
    target_role_id BIGINT NOT NULL, 
    desc_crc BIGINT NOT NULL, 
    desc_str VARCHAR(255) NOT NULL, 
    report_time BIGINT, 
    PRIMARY KEY (report_role_id, target_role_id, desc_crc)
);

CREATE TABLE global_user_report_stat (
    role_id BIGINT NOT NULL, 
    report_desc_crc BIGINT NOT NULL, 
    report_times INTEGER, 
    report_time BIGINT, 
    PRIMARY KEY (role_id, report_desc_crc)
);

CREATE TABLE global_whitelist_fpid (
    id BIGINT NOT NULL AUTO_INCREMENT, 
    PRIMARY KEY (id)
);

CREATE TABLE global_whitelist_ip (
    id BIGINT NOT NULL AUTO_INCREMENT, 
    ip_addr VARCHAR(32), 
    PRIMARY KEY (id)
);

CREATE TABLE head_icon_data (
    roleid BIGINT NOT NULL, 
    head_icon_id INTEGER NOT NULL, 
    create_time BIGINT NOT NULL, 
    expired_time BIGINT NOT NULL, 
    expired INTEGER NOT NULL, 
    PRIMARY KEY (roleid, head_icon_id)
);

CREATE TABLE hero_data (
    roleid BIGINT NOT NULL, 
    hero_id INTEGER NOT NULL, 
    hero_gid INTEGER NOT NULL, 
    level INTEGER, 
    exp INTEGER, 
    ascension_level INTEGER, 
    red_star_level INTEGER, 
    skill_level INTEGER, 
    team_info TEXT, 
    locked INTEGER, 
    equip_gid INTEGER, 
    PRIMARY KEY (roleid, hero_gid)
);

CREATE TABLE hero_team (
    roleid BIGINT NOT NULL, 
    team_id INTEGER NOT NULL, 
    team_name VARCHAR(128), 
    team_data TEXT, 
    PRIMARY KEY (roleid, team_id)
);

CREATE TABLE interactive_data (
    roleid BIGINT NOT NULL, 
    id BIGINT NOT NULL, 
    data_type INTEGER NOT NULL, 
    data_info TEXT, 
    create_time BIGINT NOT NULL, 
    update_time BIGINT NOT NULL, 
    deleted INTEGER NOT NULL, 
    PRIMARY KEY (roleid, id)
);

CREATE TABLE item_data (
    roleid BIGINT NOT NULL, 
    id INTEGER NOT NULL, 
    item_id INTEGER NOT NULL, 
    count INTEGER NOT NULL, 
    PRIMARY KEY (roleid, id)
);

CREATE INDEX ix_item_data_item_id ON item_data (item_id);

CREATE TABLE lottery_data (
    roleid BIGINT NOT NULL, 
    lottery_id INTEGER NOT NULL, 
    lottery_times INTEGER NOT NULL, 
    must_times INTEGER NOT NULL, 
    free_times INTEGER NOT NULL, 
    refresh_time BIGINT, 
    expired_time BIGINT, 
    PRIMARY KEY (roleid, lottery_id)
);

CREATE TABLE metadata (
    id BIGINT NOT NULL AUTO_INCREMENT, 
    name VARCHAR(128) NOT NULL, 
    hash VARCHAR(128) NOT NULL, 
    content TEXT NOT NULL, 
    mtime DATETIME, 
    PRIMARY KEY (id), 
    UNIQUE (name)
);

CREATE TABLE player_arena (
    roleid BIGINT NOT NULL AUTO_INCREMENT, 
    score BIGINT NOT NULL, 
    challenge_times INTEGER NOT NULL, 
    defence_team TEXT, 
    defence_formation_id INTEGER, 
    defence_team_uptime BIGINT, 
    inited_rank INTEGER, 
    defence_max_power INTEGER NOT NULL, 
    attack_max_power INTEGER NOT NULL, 
    PRIMARY KEY (roleid)
);

CREATE TABLE player_boss (
    roleid BIGINT NOT NULL AUTO_INCREMENT, 
    battle_id BIGINT, 
    rule_id INTEGER, 
    score BIGINT, 
    cur_damage BIGINT, 
    battle_end_time BIGINT, 
    take_reward_time BIGINT, 
    PRIMARY KEY (roleid)
);

CREATE TABLE player_mail (
    id BIGINT NOT NULL AUTO_INCREMENT, 
    roleid BIGINT NOT NULL, 
    sender VARCHAR(128), 
    title VARCHAR(1024), 
    content VARCHAR(4096), 
    salute VARCHAR(128), 
    attachment VARCHAR(4096), 
    read_flag INTEGER, 
    attach_received INTEGER, 
    created_time BIGINT, 
    expired_time BIGINT, 
    mail_type INTEGER, 
    global_id BIGINT, 
    mail_param VARCHAR(4096), 
    extra_conf_id INTEGER, 
    PRIMARY KEY (id)
);

CREATE INDEX ix_player_mail_roleid ON player_mail (roleid);

CREATE TABLE player_name (
    server_id INTEGER NOT NULL, 
    roleid BIGINT NOT NULL, 
    name_crc BIGINT NOT NULL, 
    name VARCHAR(128), 
    PRIMARY KEY (server_id, roleid)
);

CREATE INDEX ix_player_name_name_crc ON player_name (name_crc);

CREATE TABLE player_show_data (
    roleid BIGINT NOT NULL AUTO_INCREMENT, 
    show_hero TEXT, 
    show_dragon TEXT, 
    guild_id BIGINT NOT NULL, 
    guild_title_id INTEGER NOT NULL, 
    show_power INTEGER NOT NULL, 
    show_dungeon_id INTEGER NOT NULL, 
    create_time BIGINT NOT NULL, 
    update_time BIGINT NOT NULL, 
    show_hero_inited INTEGER, 
    PRIMARY KEY (roleid)
);

CREATE TABLE plog_setting (
    tag VARCHAR(128) NOT NULL, 
    enable_mode_list VARCHAR(255) NOT NULL, 
    log_level_site INTEGER NOT NULL, 
    log_output_site INTEGER NOT NULL, 
    unity_log_open INTEGER, 
    PRIMARY KEY (tag)
);

CREATE TABLE quality_setting (
    fpid BIGINT NOT NULL AUTO_INCREMENT, 
    device_module VARCHAR(128), 
    cpu_name VARCHAR(128), 
    cpu_core_num INTEGER, 
    gpu_shader_level INTEGER, 
    gpu_name VARCHAR(128), 
    memory_size INTEGER, 
    gpu_memory_size INTEGER, 
    config_id INTEGER, 
    PRIMARY KEY (fpid)
);

CREATE TABLE resource_data (
    roleid BIGINT NOT NULL, 
    resource_id INTEGER NOT NULL, 
    resource_value BIGINT NOT NULL, 
    last_refresh_time BIGINT, 
    PRIMARY KEY (roleid, resource_id)
);

CREATE TABLE robot_data (
    roleid BIGINT NOT NULL AUTO_INCREMENT, 
    table_id INTEGER NOT NULL, 
    role_info TEXT, 
    hero_info TEXT, 
    weapon_info TEXT, 
    dragon_info TEXT, 
    arena_info TEXT, 
    show_info TEXT, 
    create_time BIGINT NOT NULL, 
    robot_type INTEGER, 
    PRIMARY KEY (roleid), 
    UNIQUE (table_id)
);

CREATE TABLE role_info (
    roleid BIGINT NOT NULL AUTO_INCREMENT, 
    fpid BIGINT NOT NULL, 
    serverid INTEGER NOT NULL, 
    ctime BIGINT NOT NULL, 
    level INTEGER NOT NULL, 
    title_level INTEGER NOT NULL, 
    diamond_buy BIGINT, 
    diamond_gift BIGINT, 
    diamond_used BIGINT, 
    prologue_passed INTEGER, 
    gender INTEGER NOT NULL, 
    name VARCHAR(128), 
    last_logout_time BIGINT, 
    signature VARCHAR(256), 
    icon_id INTEGER NOT NULL, 
    icon_frame_id INTEGER NOT NULL, 
    mod_name_cnt INTEGER NOT NULL, 
    check_interactive_time BIGINT, 
    PRIMARY KEY (roleid)
);

CREATE INDEX ix_role_info_fpid ON role_info (fpid);

CREATE TABLE sevenday_login (
    roleid BIGINT NOT NULL, 
    id INTEGER NOT NULL, 
    timestamp BIGINT, 
    take_flag INTEGER, 
    PRIMARY KEY (roleid, id)
);

CREATE TABLE shop_data (
    roleid BIGINT NOT NULL, 
    shop_id INTEGER NOT NULL, 
    begin_time BIGINT, 
    end_time BIGINT, 
    products_blob TEXT, 
    PRIMARY KEY (roleid, shop_id)
);

CREATE TABLE task_data (
    roleid BIGINT NOT NULL, 
    task_status INTEGER NOT NULL, 
    task_sharding INTEGER NOT NULL, 
    detail_data BLOB, 
    PRIMARY KEY (roleid, task_status, task_sharding)
);

CREATE TABLE task_group (
    roleid BIGINT NOT NULL, 
    group_status INTEGER NOT NULL, 
    group_sharding INTEGER NOT NULL, 
    detail_data BLOB, 
    PRIMARY KEY (roleid, group_status, group_sharding)
);

CREATE TABLE user (
    fpid BIGINT NOT NULL, 
    serverid INTEGER NOT NULL, 
    roleid BIGINT NOT NULL, 
    ctime BIGINT NOT NULL, 
    ipaddr VARCHAR(64), 
    deleted INTEGER, 
    deleted_time BIGINT, 
    PRIMARY KEY (fpid, serverid, roleid)
);

INSERT INTO alembic_version (version_num) VALUES ('b907b2d2adc1');

