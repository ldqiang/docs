#!/bin/bash

pip3 install flask-sqlalchemy
pip3 install mysqlclient
pip3 install flask-sqlacodegen
pip3 install flask_migrate
pip3 install Flask-Script
pip3 install PyMySQL
